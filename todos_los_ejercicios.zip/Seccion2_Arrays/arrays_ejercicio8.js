// arrays_ejercicio8.js
// Recorre un array utilizando un bucle for.

let animales = ["perro", "gato", "ratón", "pájaro"];
console.log("Array original:", animales);

console.log("Recorriendo el array con un bucle for:");
for (let i = 0; i < animales.length; i++) {
  console.log("- " + animales[i]);
}

alert("Se ha recorrido un array con un bucle for. Revisa la consola.");
