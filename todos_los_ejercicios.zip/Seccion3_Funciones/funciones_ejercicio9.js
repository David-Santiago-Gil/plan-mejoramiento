// Ejercicio 9: Operador ternario para verificar aprobación
// Utiliza el operador ternario para determinar si un estudiante aprobó.

let calificacion = prompt("Ingresa la calificación del estudiante (0-10):");
let mensaje = Number(calificacion) >= 6 ? "El estudiante aprobó." : "El estudiante no aprobó.";

alert(mensaje);
