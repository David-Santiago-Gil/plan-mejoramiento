// Ejercicio 8: Operador ternario para verificar si un número es positivo
// Utiliza el operador ternario para determinar si un número es positivo.

let numero = prompt("Ingresa un número:");
let resultado = Number(numero) > 0 ? "El número es positivo." : "El número no es positivo.";

alert(resultado);
