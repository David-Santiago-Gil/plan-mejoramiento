// modulo_anonimo.js
// Este módulo exporta una función anónima por defecto.

export default () => {
  return "Función anónima exportada por defecto.";
};
