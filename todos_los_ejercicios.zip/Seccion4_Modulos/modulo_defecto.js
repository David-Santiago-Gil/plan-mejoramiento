// modulo_defecto.js
// Este módulo exporta una función por defecto.

export default function saludar() {
  return "¡Hola desde el módulo de exportación por defecto!";
}
