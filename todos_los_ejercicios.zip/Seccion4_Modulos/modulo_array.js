// modulo_array.js
// Este módulo exporta un array por defecto.

const colores = ["rojo", "verde", "azul"];

export default colores;
