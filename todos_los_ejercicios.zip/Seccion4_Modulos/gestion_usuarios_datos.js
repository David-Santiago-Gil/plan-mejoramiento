// gestion_usuarios/datos.js
// Este módulo contiene los datos de los usuarios.

export const usuarios = [
  { id: 1, nombre: "Ana" },
  { id: 2, nombre: "Luis" },
  { id: 3, nombre: "Marta" }
];
