// modulo_config.js
// Este módulo exporta constantes de configuración.

export const USUARIO_API = "admin";
export const CLAVE_API = "12345";
export const URL_API = "https://api.example.com";
