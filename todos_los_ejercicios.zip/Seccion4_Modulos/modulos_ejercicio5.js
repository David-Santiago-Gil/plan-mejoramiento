// modulos_ejercicio5.js
// Importa la función anónima del módulo de exportación por defecto.

import funcionAnonima from './modulo_anonimo.js';

let mensaje = funcionAnonima();
console.log(mensaje);

alert("Se ha importado y ejecutado una función anónima desde otro módulo. Revisa la consola.");
