// modulos_ejercicio3.js
// Importa el array del módulo de exportación por defecto.

import colores from './modulo_array.js';

console.log("Colores importados:", colores);

alert("Se ha importado un array desde otro módulo. Revisa la consola.");
