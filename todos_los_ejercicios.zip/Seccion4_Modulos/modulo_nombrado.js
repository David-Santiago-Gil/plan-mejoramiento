// modulo_nombrado.js
// Este módulo exporta varias funciones y variables con nombres.

export const PI = 3.14159;

export function sumar(a, b) {
  return a + b;
}

export function restar(a, b) {
  return a - b;
}
