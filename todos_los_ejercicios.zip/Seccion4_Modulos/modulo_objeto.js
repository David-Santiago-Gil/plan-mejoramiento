// modulo_objeto.js
// Este módulo exporta un objeto por defecto.

const persona = {
  nombre: "Juan",
  edad: 30
};

export default persona;
