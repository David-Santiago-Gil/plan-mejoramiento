// modulos_ejercicio4.js
// Importa la clase del módulo de exportación por defecto.

import Animal from './modulo_clase.js';

const animal = new Animal("León");
animal.hablar();

alert("Se ha importado y utilizado una clase desde otro módulo. Revisa la consola.");
