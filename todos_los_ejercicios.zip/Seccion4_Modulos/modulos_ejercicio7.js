// modulos_ejercicio7.js
// Importa las constantes de configuración.

import { USUARIO_API, CLAVE_API, URL_API } from './modulo_config.js';

console.log("Usuario API:", USUARIO_API);
console.log("Clave API:", CLAVE_API);
console.log("URL API:", URL_API);

alert("Se han importado constantes de configuración desde otro módulo. Revisa la consola.");
