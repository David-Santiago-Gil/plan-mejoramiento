// modulos_ejercicio1.js
// Importa la función del módulo de exportación por defecto.

import miFuncionDeSaludo from './modulo_defecto.js';

let saludo = miFuncionDeSaludo();
console.log(saludo);

alert("Se ha importado y ejecutado una función desde otro módulo. Revisa la consola.");
