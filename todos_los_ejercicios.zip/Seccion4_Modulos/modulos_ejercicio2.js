// modulos_ejercicio2.js
// Importa el objeto del módulo de exportación por defecto.

import persona from './modulo_objeto.js';

console.log("Nombre:", persona.nombre);
console.log("Edad:", persona.edad);

alert("Se ha importado un objeto desde otro módulo. Revisa la consola.");
