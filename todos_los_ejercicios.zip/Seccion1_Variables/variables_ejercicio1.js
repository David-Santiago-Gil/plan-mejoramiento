// Ejercicio 1: Saludo al usuario
// Pide al usuario su nombre y lo saluda.

let nombre = prompt("Por favor, ingresa tu nombre:");
alert("¡Hola, " + nombre + "! Bienvenido.");
