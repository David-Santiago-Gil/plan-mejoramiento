// Ejercicio 6: Demostración de parseInt()
// Convierte una cadena a un número entero.

let textoConNumero = "123_numeros";
let numeroEntero = parseInt(textoConNumero);

console.log("La cadena original es: '" + textoConNumero + "'");
console.log("El número extraído con parseInt() es: " + numeroEntero);

alert("Se ha realizado una conversión con parseInt() en la consola.");
