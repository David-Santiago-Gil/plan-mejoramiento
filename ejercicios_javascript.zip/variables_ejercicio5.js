// Ejercicio 5: Conversor de temperatura
// Pide al usuario una temperatura in Celsius y la convierte a Fahrenheit.

let celsius = prompt("Ingresa la temperatura en grados Celsius:");
let fahrenheit = (Number(celsius) * 9/5) + 32;

alert(celsius + " grados Celsius son " + fahrenheit + " grados Fahrenheit.");
